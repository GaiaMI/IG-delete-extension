(function () {
  'use strict';

  let lastState = {
    ok: true, onThread: /\/direct\/t\//.test(location.pathname), sessionOk: false,
    running: false, phase: 'idle', scanned: 0, found: 0, done: 0, failed: 0,
    lastMsg: 'engine loading...'
  };

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.__igu !== 'state') return;
    lastState = e.data.state;
  });

  const toEngine = (payload) => {
    try { window.postMessage(Object.assign({ __igu: 'cmd' }, payload), location.origin); }
    catch (err) {}
  };

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return;
    if (msg.type === 'state') { toEngine({ cmd: 'ping' }); sendResponse(lastState); return; }
    if (msg.type === 'start') { toEngine({ cmd: 'start', cfg: msg.cfg }); sendResponse(lastState); return; }
    if (msg.type === 'stop') { toEngine({ cmd: 'stop' }); sendResponse(lastState); return; }
  });
})();
