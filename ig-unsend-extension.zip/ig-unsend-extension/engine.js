(function () {
  'use strict';

  if (window.__igUnsendLoaded) return;
  window.__igUnsendLoaded = true;

  const APP_ID = '936619743392459';
  const UNSEND_DOC_ID = '26948700068153789';
  const REST_HEADERS = { 'x-ig-app-id': APP_ID, 'x-requested-with': 'XMLHttpRequest' };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const jitter = (ms) => ms + Math.floor(Math.random() * (ms * 0.3));
  const cookie = (n) => (document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)')) || [])[1];

  const state = {
    running: false,
    phase: 'idle',
    scanned: 0,
    found: 0,
    done: 0,
    failed: 0,
    lastMsg: '',
    stopReason: ''
  };

  function reset() {
    state.scanned = state.found = state.done = state.failed = 0;
    state.stopReason = '';
    state.lastMsg = '';
  }

  let TOKENS = null;

  function extractTokens(html) {
    const dtsg = (html.match(/"DTSGInitialData",\[\],\{"token":"([^"]+)"/) || [])[1];
    const lsd = (html.match(/"LSD",\[\],\{"token":"([^"]+)"/) || [])[1];
    if (!dtsg || !lsd) return null;
    let sum = 0;
    for (let i = 0; i < dtsg.length; i++) sum += dtsg.charCodeAt(i);
    return { dtsg: dtsg, lsd: lsd, jazoest: '2' + sum, av: String(cookie('ds_user_id') || '') };
  }

  function loadTokens() {
    if (TOKENS) return TOKENS;
    TOKENS = extractTokens(document.documentElement.innerHTML);
    return TOKENS;
  }

  async function refreshTokens() {
    try {
      const r = await fetch('/', { credentials: 'include' });
      const t = extractTokens(await r.text());
      if (t) { TOKENS = t; return true; }
    } catch (e) {}
    return false;
  }

  async function restGet(url) {
    const r = await fetch(url, { headers: REST_HEADERS, credentials: 'include' });
    let j = null;
    try { j = await r.json(); } catch (e) {}
    return { status: r.status, body: j };
  }

  async function unsend(threadId, messageId) {
    const t = loadTokens();
    if (!t) return 'notokens';

    const body = new URLSearchParams({
      av: t.av,
      dpr: '1',
      fb_dtsg: t.dtsg,
      jazoest: t.jazoest,
      lsd: t.lsd,
      fb_api_caller_class: 'RelayModern',
      fb_api_req_friendly_name: 'useDeleteMessageMutation',
      server_timestamps: 'true',
      variables: JSON.stringify({ message_id: messageId, send_data: { thread_id: threadId } }),
      doc_id: UNSEND_DOC_ID
    });

    let r;
    try {
      r = await fetch('/api/graphql', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'content-type': 'application/x-www-form-urlencoded',
          'x-csrftoken': cookie('csrftoken') || '',
          'x-fb-lsd': t.lsd
        },
        body: body.toString()
      });
    } catch (e) { return 'fail'; }

    if (r.status === 429) return 'blocked';

    const txt = await r.text();
    let j = null;
    try { j = JSON.parse(txt); } catch (e) {}

    if (j && j.data && j.data.direct_unsend_message === true) return 'ok';
    if (/rate limit|too many|spam|feedback_required/i.test(txt)) return 'blocked';
    if (/dtsg|csrf|login_required|not authorized/i.test(txt)) return 'auth';
    return 'fail';
  }

  const urlThreadKey = () => (location.pathname.match(/\/direct\/t\/(\d+)/) || [])[1] || null;

  function threadMatches(t, key) {
    return String(t.thread_id) === key ||
           String(t.thread_v2_id) === key ||
           String(t.messaging_thread_key) === key ||
           (t.users || []).some((u) => String(u.interop_messaging_user_fbid) === key);
  }

  async function resolveThreadId() {
    const key = urlThreadKey();
    if (!key) return { error: 'no conversation open (/direct/t/...)' };

    let cursor = null;
    for (let page = 0; page < 40 && state.running; page++) {
      state.lastMsg = 'looking up the conversation (page ' + (page + 1) + ')';
      let url = '/api/v1/direct_v2/inbox/?visual_message_return_type=unseen' +
                '&thread_message_limit=1&persistentBadging=true&limit=40';
      if (cursor) url += '&cursor=' + encodeURIComponent(cursor);

      const res = await restGet(url);
      if (res.status !== 200 || !res.body || !res.body.inbox) {
        return { error: 'inbox unreachable (HTTP ' + res.status + ')' };
      }
      const inbox = res.body.inbox;
      const hit = (inbox.threads || []).find((t) => threadMatches(t, key));
      if (hit) return { threadId: String(hit.thread_id) };

      cursor = inbox.oldest_cursor || inbox.next_cursor || null;
      if (!cursor || inbox.has_older === false) break;
      await sleep(200);
    }
    return { error: 'conversation not found in the inbox' };
  }

  async function collectMine(threadId, opts) {
    const targets = [];
    let cursor = null;
    let noId = 0;

    for (let page = 0; page < 500 && state.running; page++) {
      let url = `/api/v1/direct_v2/threads/${threadId}/?visual_message_return_type=unseen` +
                '&direction=older&limit=50';
      if (cursor) url += '&cursor=' + encodeURIComponent(cursor);

      const res = await restGet(url);
      if (res.status === 429) return { targets, error: 'Instagram rate limit hit while reading' };
      if (res.status !== 200 || !res.body) {
        return { targets, error: 'could not read the thread (HTTP ' + res.status + ')' };
      }

      const th = res.body.thread || res.body;
      const items = th.items || [];
      state.scanned += items.length;

      let tooOld = false;
      for (const it of items) {
        const ms = Number(it.timestamp) / 1000;
        if (opts.from && ms < opts.from) { tooOld = true; continue; }
        if (opts.until && ms > opts.until) continue;
        if (it.is_sent_by_viewer !== true) continue;
        const mid = String(it.message_id || '');
        if (mid.indexOf('mid.') !== 0) { noId++; continue; }
        targets.push({ mid: mid, ms: ms, type: it.item_type });
        if (opts.max > 0 && targets.length >= opts.max) return { targets, noId };
      }

      state.found = targets.length;
      state.lastMsg = state.scanned + ' messages read, ' + targets.length + ' to unsend';

      if (tooOld && opts.from) return { targets, noId };
      if (!th.has_older) return { targets, noId };

      cursor = th.oldest_cursor;
      if (!cursor) return { targets, noId };

      await sleep(opts.readDelay);
    }
    return { targets, noId };
  }

  let badge = null, badgeTxt = null;

  function ensureBadge() {
    if (badge && badge.isConnected) return;
    const h = document.createElement('div');
    h.style.cssText = 'position:fixed;z-index:2147483647;right:16px;bottom:16px;';
    const sh = h.attachShadow({ mode: 'open' });
    sh.innerHTML =
      '<style>:host{all:initial}' +
      '.b{display:flex;align-items:center;gap:10px;background:#1b1b1d;color:#eee;' +
      'border:1px solid #3a3a3d;border-radius:10px;padding:8px 10px;' +
      'font:12px/1.3 system-ui,-apple-system,Segoe UI,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.45)}' +
      'button{border:0;border-radius:6px;background:#c13515;color:#fff;padding:5px 9px;' +
      'font:600 11px system-ui;cursor:pointer}</style>' +
      '<div class="b"><span id="t">...</span><button id="s">Stop</button></div>';
    sh.getElementById('s').addEventListener('click', () => {
      state.running = false;
      state.stopReason = 'stopped manually';
    });
    badgeTxt = sh.getElementById('t');
    document.documentElement.appendChild(h);
    badge = h;
  }

  function removeBadge() {
    if (badge && badge.isConnected) badge.remove();
    badge = null;
  }

  function paint() {
    if (!badgeTxt) return;
    if (state.phase === 'resolve') badgeTxt.textContent = state.lastMsg || 'looking up...';
    else if (state.phase === 'scan') badgeTxt.textContent = 'reading: ' + state.scanned + ' read, ' + state.found + ' targets';
    else if (state.phase === 'delete') {
      badgeTxt.textContent = state.done + ' / ' + state.found + ' unsent' +
        (state.failed ? ' (' + state.failed + ' failed)' : '');
    } else badgeTxt.textContent = state.stopReason + ' - ' + state.done + ' unsent';
  }

  function finish(reason) {
    state.running = false;
    state.phase = 'done';
    state.stopReason = reason;
    state.lastMsg = reason;
    paint();
    setTimeout(removeBadge, 9000);
  }

  async function start(cfg) {
    if (state.running) return;
    reset();
    state.running = true;
    state.phase = 'resolve';
    ensureBadge();
    paint();

    if (!loadTokens()) {
      const ok = await refreshTokens();
      if (!ok) return finish('session tokens not found - reload the page');
    }

    const from = cfg.from ? new Date(cfg.from + 'T00:00:00').getTime() : null;
    const until = cfg.until ? new Date(cfg.until + 'T23:59:59').getTime() : null;
    const delay = Math.max(0, Number(cfg.delay) || 0);

    const t = await resolveThreadId();
    if (t.error) return finish(t.error);
    if (!state.running) return finish('stopped manually');

    state.phase = 'scan';
    paint();

    const col = await collectMine(t.threadId, {
      from: from, until: until, max: Number(cfg.max) || 0,
      readDelay: Math.max(150, delay)
    });
    const targets = col.targets || [];
    state.found = targets.length;

    if (col.error && !targets.length) return finish(col.error);
    if (!targets.length) return finish('no messages to unsend in that range');

    if (cfg.dry) {
      const d = targets.map((c) => c.ms).sort((a, b) => a - b);
      return finish('dry run: ' + targets.length + ' message(s) would be unsent (from ' +
        new Date(d[0]).toLocaleDateString() + ' to ' + new Date(d[d.length - 1]).toLocaleDateString() + ')');
    }

    state.phase = 'delete';
    paint();

    targets.sort((a, b) => a.ms - b.ms);

    let streak = 0;
    let authRetry = 0;

    for (const c of targets) {
      if (!state.running) { state.stopReason = state.stopReason || 'stopped manually'; break; }

      let res = await unsend(t.threadId, c.mid);

      if (res === 'auth' || res === 'notokens') {
        if (authRetry < 2 && await refreshTokens()) {
          authRetry++;
          res = await unsend(t.threadId, c.mid);
        }
      }

      if (res === 'blocked') { state.stopReason = 'Instagram rate limited the action - try again later'; break; }
      if (res === 'ok') { state.done++; streak = 0; }
      else { state.failed++; streak++; }
      paint();

      if (streak >= 5) { state.stopReason = '5 failures in a row - stopped'; break; }
      if (delay > 0) await sleep(jitter(delay));
    }

    finish(state.stopReason || 'done');
  }

  function snapshot() {
    return {
      ok: true,
      onThread: !!urlThreadKey(),
      sessionOk: !!cookie('ds_user_id') && !!cookie('csrftoken') && !!loadTokens(),
      running: state.running,
      phase: state.phase,
      scanned: state.scanned,
      found: state.found,
      done: state.done,
      failed: state.failed,
      lastMsg: state.lastMsg || state.stopReason || ''
    };
  }

  function publish() {
    try { window.postMessage({ __igu: 'state', state: snapshot() }, location.origin); } catch (e) {}
  }

  const paintOrig = paint;
  paint = function () { paintOrig(); publish(); };

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.__igu !== 'cmd') return;
    if (e.data.cmd === 'start') { start(e.data.cfg); publish(); }
    else if (e.data.cmd === 'stop') {
      state.running = false;
      state.stopReason = 'stopped manually';
      publish();
    } else if (e.data.cmd === 'ping') publish();
  });

  setInterval(publish, 600);
  publish();
})();
