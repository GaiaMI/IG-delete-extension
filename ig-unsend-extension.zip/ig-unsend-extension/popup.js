const PRESETS = {
  careful: { delay: 800, hint: 'Safest option for large conversations.' },
  normal:  { delay: 350, hint: 'Good balance, roughly 3 unsends per second.' },
  fast:    { delay: 150, hint: 'Fast. Keep an eye on the failure count.' },
  turbo:   { delay: 60,  hint: 'No margin. Instagram may rate limit your account.' },
  custom:  { delay: 300, hint: 'Delay set by hand.' }
};

const $ = (id) => document.getElementById(id);
const DEFAULTS = { preset: 'normal', delay: 350, from: '', until: '', max: 0, dry: true };

let tabId = null;

function readForm() {
  return {
    preset: $('preset').value,
    delay: Math.max(0, parseInt($('delay').value, 10) || 0),
    from: $('from').value,
    until: $('until').value,
    max: Math.max(0, parseInt($('max').value, 10) || 0),
    dry: $('dry').checked
  };
}

function applyForm(c) {
  $('preset').value = PRESETS[c.preset] ? c.preset : 'normal';
  $('delay').value = c.delay;
  $('from').value = c.from;
  $('until').value = c.until;
  $('max').value = c.max;
  $('dry').checked = c.dry;
  showHint();
}

function showHint() {
  const k = $('preset').value;
  const p = PRESETS[k] || PRESETS.normal;
  $('speedHint').textContent = p.hint;
  $('speedHint').className = (k === 'turbo' || k === 'fast') ? 'hint warn' : 'hint';
}

const save = () => chrome.storage.local.set({ cfg: readForm() });

$('preset').addEventListener('change', () => {
  const k = $('preset').value;
  if (k !== 'custom') $('delay').value = PRESETS[k].delay;
  showHint();
  save();
});

['delay', 'from', 'until', 'max'].forEach((id) =>
  $(id).addEventListener('change', () => {
    if (id === 'delay') { $('preset').value = 'custom'; showHint(); }
    save();
  })
);
$('dry').addEventListener('change', save);

function send(msg) {
  return new Promise((resolve) => {
    if (tabId == null) return resolve(null);
    chrome.tabs.sendMessage(tabId, msg, (resp) => {
      if (chrome.runtime.lastError) return resolve(null);
      resolve(resp);
    });
  });
}

function setStatus(text, bad) {
  $('status').textContent = text;
  $('status').className = bad ? 'bad' : '';
}

function render(st) {
  if (!st) {
    setStatus('No Instagram tab found - open a conversation and reload the page.', true);
    $('go').disabled = true;
    $('stop').disabled = true;
    return;
  }

  if (!st.sessionOk) {
    setStatus('Instagram session not detected - reload the page.', true);
    $('go').disabled = true;
  } else if (!st.onThread) {
    setStatus('Open a conversation (/direct/t/...).', true);
    $('go').disabled = true;
  } else if (st.running) {
    setStatus(st.phase === 'scan' ? 'Reading the thread...' : 'Unsending...');
    $('go').disabled = true;
  } else {
    setStatus('Ready.');
    $('go').disabled = false;
  }
  $('stop').disabled = !st.running;

  const l = [];
  if (st.scanned) l.push('read    : ' + st.scanned);
  if (st.found) l.push('targets : ' + st.found);
  if (st.done) l.push('unsent  : ' + st.done);
  if (st.failed) l.push('failed  : ' + st.failed);
  if (st.lastMsg) l.push(st.lastMsg);
  $('counters').textContent = l.length ? l.join('\n') : 'idle';
}

const refresh = async () => render(await send({ type: 'state' }));

$('go').addEventListener('click', async () => {
  const c = readForm();
  if (!c.dry) {
    const scope = (c.from || c.until)
      ? 'from ' + (c.from || 'the beginning') + ' to ' + (c.until || 'today')
      : 'the ENTIRE conversation';
    if (!confirm('Permanently unsend your messages: ' + scope + '?\n\nThis cannot be undone.')) return;
  }
  save();
  await send({ type: 'start', cfg: c });
  refresh();
});

$('stop').addEventListener('click', async () => { await send({ type: 'stop' }); refresh(); });

(async function init() {
  const store = await chrome.storage.local.get('cfg');
  applyForm(Object.assign({}, DEFAULTS, store.cfg || {}));

  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs.length && /^https:\/\/www\.instagram\.com\//.test(tabs[0].url || '')) tabId = tabs[0].id;

  refresh();
  setInterval(refresh, 700);
})();
